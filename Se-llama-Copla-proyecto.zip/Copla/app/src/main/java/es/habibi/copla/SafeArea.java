package es.habibi.copla;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

final class SafeArea {
 static void install(Activity activity, View root) {
  if (Build.VERSION.SDK_INT >= 30) activity.getWindow().setDecorFitsSystemWindows(false);
  else activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
  root.setOnApplyWindowInsetsListener((view, insets) -> {
   if (Build.VERSION.SDK_INT >= 30) {
    android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
    view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
   } else {
    view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
   }
   return insets;
  });
  root.requestApplyInsets();
 }
 static void fullscreen(Activity activity, View root, boolean full) {
  if (Build.VERSION.SDK_INT >= 30) {
   WindowInsetsController controller = activity.getWindow().getInsetsController();
   if (controller != null) {
    controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    if (full) controller.hide(WindowInsets.Type.systemBars());
    else controller.show(WindowInsets.Type.systemBars());
   }
  } else {
   int layout = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
   activity.getWindow().getDecorView().setSystemUiVisibility(layout | (full ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY : 0));
  }
  root.requestApplyInsets();
 }
}
