# Se llama Copla 1.1.4
Android 8 o posterior. Catálogo revisado el 30/09/2026: 309 vídeos largos de fuentes oficiales, 129 de CanalSur Más y 180 de YouTube. No representa el archivo íntegro y puede contener distintas publicaciones de una misma gala. Una copia entre plataformas con fecha coincidente fue reunida en la ficha de CanalSur Más.

CanalSur Más: 118 galas y 11 especiales de El desafío. Se verificaron todos los manifiestos HLS y se obtuvo la duración real. Fechas originales tomadas de los nombres de los archivos de RTVA; temporadas deducidas de esas fechas. La temporada 1 contiene programas 1–24, la 2 programas 1–29, la 3 programas 1–32, y la 4 programas 1–32 más Gran Gala Final. En El desafío de 2010 se localizaron programas 1,2,3,4,6,8,9,10,11,12; no se localizaron los 5 y 7. También se incluye el especial Feria de Jerez 2016.

YouTube: revisión paginada del buscador del canal oficial (503 resultados) y dos listas oficiales. Sólo se incluyen vídeos de más de 50 minutos. Las fechas se toman de las descripciones de emisión o de los títulos cuando existen; el contenido sin fecha identificable se muestra por separado. No se han comprobado en Android las restricciones de inserción de todos los vídeos de YouTube.

Reproducción: CanalSur Más utiliza ExoPlayer nativo integrado, controles de pausa, desplazamiento, anterior/siguiente y pantalla completa horizontal. YouTube utiliza su reproductor oficial dentro de WebView. Historial, minuto de reproducción y favoritos se guardan en SharedPreferences. Los datos anteriores permanecen al actualizar la APK sin desinstalar. Se han comprobado los filtros, el puente al reproductor nativo, historial, favoritos y navegación. No se ha probado en un móvil físico.

No necesita cuenta en esta app. Sólo permiso INTERNET. No se descargan los programas. La app no incorpora credenciales ni tokens del servicio de CanalSur Más; reproduce sus recursos públicos oficiales.

La web de CanalSur Más devolvió acceso denegado en navegador y en peticiones directas. Se accedió al catálogo mediante el servicio público de lectura documentado por el extractor de yt-dlp para CanalSur Más. Se revisaron la categoría 7800, las búsquedas del nombre del programa, copla, nombres de presentadora/ganadoras, fechas y especiales. Los recursos de otros programas encontrados en esas búsquedas fueron descartados.

Compilación: JDK 17, Gradle 8.10.2, Android Gradle Plugin 8.7.3, SDK 35, build tools 35.0.0, AndroidX Media3 1.5.1. Configure local.properties para su SDK y ejecute gradle :app:assembleRelease. APK firmada con el mismo certificado de desarrollo de la primera versión para actualización directa.

Logos: https://www.canalsur.es/static/logos/canalsur.svg y cartel oficial https://www.canalsur.es/rtva/canal-sur-en-el-mundo/llama-copla_1_1181369.html . Logo del programa mostrado mediante recorte CSS del cartel, sin recrearlo. Aplicación independiente, sin afiliación con Canal Sur. Todos los contenidos y marcas pertenecen a sus titulares.

## Corrección 1.1.1
El catálogo y el reproductor respetan los márgenes de las barras del sistema. Los controles del reproductor se distribuyen en dos filas, con botones de 56 dp y etiquetas en una línea. La pantalla completa actualiza los márgenes al mostrar u ocultar las barras. Mantiene el paquete, firma e historial de la versión anterior.

## Corrección 1.1.2
En horizontal se activa la pantalla completa automáticamente. El vídeo ocupa toda el área disponible conservando su proporción. Los controles se superponen, se ocultan tras cuatro segundos durante reproducción y reaparecen al tocar el vídeo; permanecen visibles al pausar. El botón Salir y Atrás regresan a vertical.

## Corrección 1.1.3
La interfaz queda limitada al ancho visible, sin desplazamiento horizontal ni rebote lateral. Categorías en varias líneas y navegación inferior flexible para pantallas estrechas. Mantiene el desplazamiento vertical y los reproductores oficiales.

## Icono 1.1.4
Nuevo icono vectorial: peineta con borde dorado y bandera andaluza verde-blanca-verde sobre fondo oscuro. Incluye el bloqueo de desplazamiento lateral de 1.1.3.
